import React from 'react';

function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-blue-50">
      <h1 className="text-4xl font-bold mb-4">TutorConnect</h1>
      <p className="mb-6 text-gray-700">
        Get any concept clarified by expert tutors. Pay only for what you learn!
      </p>
      <div>
        <a href="/register" className="bg-blue-600 text-white px-4 py-2 rounded mr-4">
          Find a Tutor
        </a>
        <a href="/tutor-register" className="bg-green-600 text-white px-4 py-2 rounded">
          Become a Tutor
        </a>
      </div>
    </div>
  );
}

export default App;